# Symport CMS Version

## Deployment Guide
1. Install Sanity CLI and login
2. Run `sanity init` inside `/sanity`
3. Connect projectId: `fzj4j572` and dataset: `production`
4. Push schemas with `sanity deploy`
5. Connect frontend to Sanity using `lib/sanity.js`
