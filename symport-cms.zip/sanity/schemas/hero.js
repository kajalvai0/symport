// Sanity schema for Hero section
