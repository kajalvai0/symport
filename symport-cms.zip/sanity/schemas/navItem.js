// Sanity schema for Navbar items
