// Hero section using Sanity data
